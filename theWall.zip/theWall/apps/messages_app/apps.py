from django.apps import AppConfig


class MessagesAppConfig(AppConfig):
    name = 'messages_app'
